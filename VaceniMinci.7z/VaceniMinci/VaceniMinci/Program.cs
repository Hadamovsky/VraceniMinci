﻿using System;

namespace VaceniMinci
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Cena zbozi:");
            int cena = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Cim platite?");
            int platidlo = Convert.ToInt32(Console.ReadLine());
            int vraceni = platidlo - cena;
            if (cena >= platidlo)
            {
                Console.WriteLine("Nic nemusim vracet.");
            }
               else if (vraceni % 50 == 0)
                {
                    int mince50 = vraceni / 50;
                    Console.WriteLine("Vraceno {0} x 50 Kc minci", mince50);
                }
                else 
                {
                    int zbytek50 = vraceni % 50;
                    int mince50 = (vraceni - zbytek50) / 50;
                    Console.WriteLine("Vraceno {0} x 50 Kc minci", mince50);

                    if (zbytek50 % 20 == 0)
                    {
                        int mince20 = zbytek50 / 20;
                        Console.WriteLine("Vraceno {0} x 20 Kc minci", mince20);
                    }
                    else
                    {
                        int zbytek20 = zbytek50 % 20;
                        int mince20 = (zbytek50 - zbytek20) / 20;
                        Console.WriteLine("Vraceno {0} x 20 Kc minci", mince20);

                    if (zbytek20 % 10 == 0)
                    {
                        int mince10 = zbytek20 / 10;
                        Console.WriteLine("Vraceno {0} x 10 Kc minci", mince10);
                    }
                    else
                    {
                        int zbytek10 = zbytek20 % 10;
                        int mince10 = (zbytek20 - zbytek10) / 10;
                        Console.WriteLine("Vraceno {0} x 10 Kc minci", mince10);

                        if (zbytek10 % 5 == 0)
                        {
                            int mince5 = zbytek10 / 5;
                            Console.WriteLine("Vraceno {0} x 5 Kc minci", mince5);
                        }
                        else
                        {
                            int zbytek5 = zbytek10 % 5;
                            int mince5 = (zbytek10 - zbytek5) / 5;
                            Console.WriteLine("Vraceno {0} x 5 Kc minci", mince5);

                            if (zbytek5 % 2 == 0)
                            {
                                int mince2 = zbytek5 / 2;
                                Console.WriteLine("Vraceno {0} x 2 Kc minci", mince2);
                            }
                            else
                            {
                                int zbytek2 = zbytek5 % 2;
                                int mince2 = (zbytek5 - zbytek2) / 2;
                                Console.WriteLine("Vraceno {0} x 2 Kc minci", mince2);
                                Console.WriteLine("Vraceno 1 x 1 Kc minci");

                                
                            }
                        }
                    }
                    }
                }
            

            Console.ReadLine();

          

        }
    }
}
